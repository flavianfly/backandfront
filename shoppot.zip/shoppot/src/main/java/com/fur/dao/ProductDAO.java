package com.fur.dao;

import java.util.List;

import com.fur.model.Product;

public interface ProductDAO {
 

 public List getList();

 public Product getRowById(int id);

 public int updateRow(Product prod);

 public int deleteRow(int id);

public int insertRow(Product prod, String s);

}

