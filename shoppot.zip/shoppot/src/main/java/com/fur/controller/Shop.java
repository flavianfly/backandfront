package com.fur.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class Shop {
	public Shop() {

		System.out.println("inside controller");
	}

	@RequestMapping("/")
	public String gotoindexPage() {
		return "index";
	}

	@RequestMapping("/invalid")
	public String gotoinvalidPage() {
		return "invalid";
	}

	@RequestMapping("/index")
	public String gotoHome() {
		return "index";
	}

	@RequestMapping("/register")
	public String gotoregister() {
		return "register";
	}

	@RequestMapping("/welcome")
	public String gotowelcome() {
		return "welcome";
	}
	
	@RequestMapping("/hall")
	public String gotohall() {
		return "hall";
	}
	
	@RequestMapping("/bedroom")
	public String gotobedroom() {
		return "bedroom";
	}
	

	@RequestMapping("/dinning")
	public String gotodinning() {
		return "dinning";
	}
	
	@RequestMapping("/ha1")
	public String gotoha1() {
		return "ha1";
	}

	@RequestMapping("/ha2")
	public String gotoha2() {
		return "ha2";
	}
	
	@RequestMapping("/ha3")
	public String gotoha3() {
		return "ha3";
	}
	
	@RequestMapping("/ha4")
	public String gotoha4() {
		return "ha4";
	}


	@RequestMapping(value = "/checkLogin",method = RequestMethod.POST)
	public String validateLogin(HttpServletRequest req) {
		String u = req.getParameter("username");
		String pass = req.getParameter("pwd");
		if ((u.equals("abc")) && (pass.equals("def")))
		{
			return "welcome";
		} 
		else 
		{

			return "invalid";
		}

	}
}
